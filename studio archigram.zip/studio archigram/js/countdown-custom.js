jQuery(document).ready(function() {
        $(function () {
            $('#defaultCountdown').countdown({until: new Date(2024, 6, 20, 8)}); // year, month, date, hour
        });
});		

